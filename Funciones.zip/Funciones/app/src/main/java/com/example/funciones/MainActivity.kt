package com.example.funciones

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {

    var TV: TextView? = null
    var RB: RadioButton? = null
    var RB2: RadioButton? = null
    var RB3: RadioButton? = null
    var RB4: RadioButton? = null
    var ET: EditText? = null
    var ET2: EditText? = null
    var ET3: EditText?= null
    var BT: Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        this.TV = this.findViewById(R.id.textView)
        this.RB = this.findViewById(R.id.radioButton5)
        this.RB2 = this.findViewById(R.id.radioButton2)
        this.RB3 = this.findViewById(R.id.radioButton3)
        this.RB4 = this.findViewById(R.id.radioButton4)
        this.ET = this.findViewById(R.id.editTextNumber3)
        this.ET2 = this.findViewById(R.id.editTextNumber)
        this.ET3 = this.findViewById(R.id.editTextNumber2)
        this.BT = this.findViewById(R.id.button)

        empieza()

        //AREA DE BOTONES
        RB?.setOnClickListener() {
            //ET?.setVisibility(View.GONE)
            ET?.isVisible = true
            ET2?.isVisible = true
            ET3?.isVisible = true
            ET?.hint = "Ingrese un numero"
            ET2?.hint = "Ingrese un numero"
            ET3?.hint = "Ingrese un numero"
            BT?.setOnClickListener {
                val res = funcionsimple(ET?.text.toString().toInt(),ET2?.text.toString().toInt(),ET3?.text.toString().toInt())
                TV?.setText("El resultado es $res")
                limpiaet()
            }
        }
        RB2?.setOnClickListener {
            ET?.isVisible = true
            ET2?.isVisible = true
            ET3?.isVisible = false
            ET?.hint = "Ingrese un numero"
            BT?.setOnClickListener {
                val res = funcionconparametro(ET?.text.toString().toInt(),ET2?.text.toString().toInt())
                TV?.setText("El resultado es $res")
                limpiaet()
            }
        }
        RB3?.setOnClickListener {
            ET?.isVisible = true
            ET2?.isVisible = true
            ET3?.isVisible = true
            ET?.hint = "Ingrese un numero"
            ET2?.hint = "Ingrese un numero"
            BT?.setOnClickListener {
                val res = funcion2parametros(ET?.text.toString().toInt(),ET2?.text.toString().toInt(),ET3?.text.toString().toInt())
                TV?.setText("El resultado es $res")
                limpiaet()
            }
        }

        RB4?.setOnClickListener {
            ET?.isVisible = false
            ET2?.isVisible = true
            ET3?.isVisible = true
            ET2?.hint = "Ingrese un numero"
            ET3?.hint = "Ingrese otro numero"
            BT?.setOnClickListener {
                val res = funcionconretorno(ET2?.text.toString().toDouble(), ET3?.text.toString().toDouble())
                TV?.setText("El resultado es $res")
                limpiaet()
            }
        }


    }



    // AREA DE FUNCIONES
    fun funcionsimple(no1:Int, no2:Int, no3:Int): Int {
        var r = no1 + no2 + no3
        return r
    }

    fun funcionconparametro(no1:Int, no2:Int): Int {
        var s = no1 - no2
        return s
    }

    fun funcion2parametros(no1:Int, no2:Int, no3:Int): Int {
        var t = no1 * no2 * no3
        return t
    }

    fun funcionconretorno(num1:Double, num2:Double):Double{
        var n = num1 / num2
        return n
    }

    fun limpiaet(){
        ET?.setText("")
        ET2?.setText("")
        ET3?.setText("")
    }

    fun empieza(){
        ET?.isVisible = false
        ET2?.isVisible = false
        ET3?.isVisible = false
    }



}
